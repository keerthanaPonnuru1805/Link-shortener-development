# URL_Shortener
This is a URL shortener website built using Node.js, JavaScript, and MongoDB. It provides a simple and efficient way to convert long URLs into short, easy-to-share links.
<img width="948" alt="Screenshot 2023-07-13 220050" src="https://github.com/geek-prateek/URL_Shortener/assets/71647878/26dd3197-3b11-473e-9498-72e3f6831c78">
